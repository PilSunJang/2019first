﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MultiChatClient
{
    public partial class Solo_Talk : Form
    {
        Client cliForm;
        string connectUser;

        public Solo_Talk(Client clF)
        {
            InitializeComponent();
            this.cliForm = clF;
        }
        // 실행
        private void Solo_Talk_Load(object sender, EventArgs e)
        {
            if(cliForm.recvDt == "")
            {
                connectUser = cliForm.ClientList.CheckedItems[0].ToString();
                this.Text = "Solo Talk ( " + connectUser + " )";
                for (int i = cliForm.ClientList.Items.Count - 1; i >= 0; i--)
                    cliForm.ClientList.SetItemCheckState(i, CheckState.Unchecked);
            }
            else
            {
                string[] tokens = cliForm.recvDt.Split('\x01');
                connectUser = tokens[0];
                this.Text = "Solo Talk ( " + connectUser + " )";
                AppendText(txtHistory, string.Format("[받음] > {0}", tokens[2]));
                cliForm.recvDt = "";
            }
        }
        // 창 활성화 시 실행
        public void Solo_Talk_Activated(object sender, EventArgs e)
        {
            if (cliForm.recvDt != "")
            {
                string[] tokens = cliForm.recvDt.Split('\x01');
                AppendText(txtHistory, string.Format("[받음] > {0}", tokens[2]));
                cliForm.recvDt = "";
            }
        }
        // 보내기 버튼
        private void Send_Data(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTTS.Text.Trim()))
            {
                txtTTS.Focus();
                return;
            }
            cliForm.recvDt = connectUser + '\x01' + txtTTS.Text;
            AppendText(txtHistory, string.Format("[보냄] < {0}", txtTTS.Text));
            txtTTS.Clear();
            txtTTS.Focus();
            cliForm.TalkSend();
        }
        // 보내기 버튼 실행
        private void QuickSend(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnSend.PerformClick();
        }
        // 텍스트 붙이는 함수
        void AppendText(Control ctrl, string s)
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                ctrl.Text += Environment.NewLine + s;
                txtHistory.SelectionStart = txtHistory.Text.Length;
                txtHistory.ScrollToCaret();
            }));
        }
    }
}
