﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace MultiChatClient {
    public partial class Client : Form {
        delegate void AppendTextDelegate(Control ctrl, string s);
        Socket mainSock;
        bool ServerConnected = false;
        public string recvDt = "";
        public string pictureDt = "";

        public Client()
        {
            InitializeComponent();
            mainSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
            AppendTextDelegate Appender = new AppendTextDelegate(AppendText);
        }
        // 실행
        public void OnFormLoaded(object sender, EventArgs e)
        {
            IPHostEntry he = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress defaultHostAddress = null;
            foreach (IPAddress addr in he.AddressList)
            {
                if (addr.AddressFamily == AddressFamily.InterNetwork)
                {
                    defaultHostAddress = addr;
                    break;
                }
            }
            if (defaultHostAddress == null)
                defaultHostAddress = IPAddress.Loopback;
            txtAddress.Text = defaultHostAddress.ToString();
        }
        // 연결 버튼
        public void OnConnectToServer(object sender, EventArgs e)
        {
            if (ServerConnected)
            {
                MsgBoxHelper.Error("이미 연결되어 있습니다!");
                return;
            }
            int port;
            if (!int.TryParse(txtPort.Text, out port))
            {
                MsgBoxHelper.Error("포트 번호가 잘못 입력되었거나 입력되지 않았습니다.");
                txtPort.Focus();
                txtPort.SelectAll();
                return;
            }
            try { mainSock.Connect(txtAddress.Text, port); }
            catch (Exception ex)
            {
                MsgBoxHelper.Error("연결에 실패했습니다!\n오류 내용: {0}", MessageBoxButtons.OK, ex.Message);
                return;
            }
            AppendText(txtHistory, "서버와 연결되었습니다.");
            ServerConnected = true;
            AsyncObject obj = new AsyncObject(50000);
            obj.WorkingSocket = mainSock;
            mainSock.BeginReceive(obj.Buffer, 0, obj.BufferSize, 0, DataReceived, obj);
        }
        // 보내기 버튼
        public void OnSendData(object sender, EventArgs e)
        {
            if (!mainSock.IsBound)
                return;
            string tts = txtTTS.Text.Trim();
            if (string.IsNullOrEmpty(tts))
            {
                txtTTS.Focus();
                return;
            }
            IPEndPoint ip = (IPEndPoint) mainSock.LocalEndPoint;
            byte[] bDts = Encoding.UTF8.GetBytes(ip.ToString() + '\x01' + tts);
            mainSock.Send(bDts);
            AppendText(txtHistory, string.Format("[보냄]{0}: {1}", ip.ToString(), tts));
            txtTTS.Clear();
        }
        // 보내기 버튼 실행키
        private void QuickSend(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnSend.PerformClick();
        }
        // 채팅방 생성 버튼
        private void CreateTalk(object sender, EventArgs e)
        {
            if (ClientList.CheckedItems.Count == 0)
            {
                MsgBoxHelper.Error("사용자를 선택해주세요.");
                return;
            }
            for (int i = ClientList.CheckedItems.Count - 1; i >= 0; i--)
            {
                if (mainSock.LocalEndPoint.ToString().Equals(ClientList.CheckedItems[i].ToString()))
                {
                    MsgBoxHelper.Error("본인을 제외한 사용자를 선택해주세요.");
                    return;
                }
            }
            if (ClientList.CheckedItems.Count == 1)
            {
                foreach (Form OpenForm in Application.OpenForms)
                {
                    if (OpenForm.Text == "Solo Talk ( " + ClientList.CheckedItems[0].ToString() + " )")
                    {
                        MsgBoxHelper.Error("이미 대화중입니다.");
                        OpenForm.Activate();
                        return;
                    }
                }
                Solo_Talk st = new Solo_Talk(this);
                st.Show();
            }
            else
            {
                Group_Talk gt = new Group_Talk(this, mainSock.LocalEndPoint.ToString());
                gt.Show();
            }
        }
        // 그림 맞추기방 버튼
        private void OpenPaintGame(object sender, EventArgs e)
        {

            if (ClientList.CheckedItems.Count == 0)
            {
                MsgBoxHelper.Error("사용자를 선택해주세요.");
                return;
            }
            for (int i = ClientList.CheckedItems.Count - 1; i >= 0; i--)
            {
                if (mainSock.LocalEndPoint.ToString().Equals(ClientList.CheckedItems[i].ToString()))
                {
                    MsgBoxHelper.Error("본인을 제외한 사용자를 선택해주세요.");
                    return;
                }
            }
            Paint_Game pg = new Paint_Game(this, mainSock.LocalEndPoint.ToString());
            pg.Show();
        }
        // 종료 시 연결 종료
        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (mainSock.Connected)
            {
                byte[] closeInfo = Encoding.UTF8.GetBytes(mainSock.LocalEndPoint.ToString() + '\x02');
                mainSock.Send(closeInfo);
                return;
            }
        }
        // 다른 창에서 메세지 보내는 함수
        public void TalkSend()
        {
            string[] tokens = recvDt.Split('\x01');
            if (pictureDt != "") 
            {
                Byte[] bDts = Encoding.UTF8.GetBytes(pictureDt + '\x04' + recvDt);
                pictureDt = "";
                recvDt = "";
                mainSock.Send(bDts);
            }
            else if (tokens[0].Contains("\x02"))
            {
                byte[] bDts = Encoding.UTF8.GetBytes(mainSock.LocalEndPoint.ToString() + '\x01' + recvDt);
                recvDt = "";
                mainSock.Send(bDts);
            }
            else if (tokens.Length > 3)
            {
                byte[] bDts = Encoding.UTF8.GetBytes(mainSock.LocalEndPoint.ToString() + '\x01' + recvDt);
                recvDt = "";
                mainSock.Send(bDts);
            }
            else
            {
                byte[] bDts = Encoding.UTF8.GetBytes(mainSock.LocalEndPoint.ToString() + '\x01' + recvDt);
                recvDt = "";
                mainSock.Send(bDts);
            }
        }
        // 텍스트 붙이는 함수
        void AppendText(Control ctrl, string s)
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                ctrl.Text += Environment.NewLine + s;
                txtHistory.SelectionStart = txtHistory.Text.Length;
                txtHistory.ScrollToCaret();
            }));
        }
        // 데이터 수신 함수
        void DataReceived(IAsyncResult ar)
        {
            AsyncObject obj = (AsyncObject)ar.AsyncState;
            string text = Encoding.UTF8.GetString(obj.Buffer);
            if (text.Contains("\x04"))
            {
                string[] InfoDt = text.Split('\x04');
                string[] tokens = InfoDt[1].Split('\x01');
                int cnt = int.Parse(tokens[0]);
                pictureDt = InfoDt[0];
                this.Invoke(new MethodInvoker(delegate ()
                {
                    foreach (Form OpenForm in Application.OpenForms)
                    {
                        if (OpenForm.Text == "Drawing Catch ( " + cnt + " 명 )")
                        {
                            OpenForm.Activate();
                            return;
                        }
                    }
                    Paint_Game pg = new Paint_Game(this, mainSock.LocalEndPoint.ToString());
                    pg.Show();
                }));
            }
            else if (text.Contains("\x01"))
            {
                string[] tokens = text.Split('\x01');
                if (tokens[1].Contains("\x02"))
                {
                    string[] Infom = tokens[1].Split('\x02');
                    int cnt = int.Parse(Infom[0]);
                    recvDt = text;
                    this.Invoke(new MethodInvoker(delegate ()
                    {
                        foreach (Form OpenForm in Application.OpenForms)
                        {
                            if (OpenForm.Text == "Drawing Catch ( " + cnt + " 명 )")
                            {
                                OpenForm.Activate();
                                return;
                            }
                        }
                        Paint_Game pg = new Paint_Game(this, mainSock.LocalEndPoint.ToString());
                        pg.Show();
                    }));
                }
                else if(tokens.Length == 2)
                    AppendText(txtHistory, string.Format("[받음]{0}: {1}", tokens[0], tokens[1]));
                else if(tokens.Length == 3)
                {
                    recvDt = text;
                    this.Invoke(new MethodInvoker(delegate ()
                    {
                        foreach (Form OpenForm in Application.OpenForms)
                        {
                            if(OpenForm.Text == "Solo Talk ( " + tokens[0] + " )")
                            {
                                OpenForm.Activate();
                                return;
                            }
                        }
                        Solo_Talk st = new Solo_Talk(this);
                        st.Show();
                    }));
                }
                else if (tokens.Length >= 4)
                {
                    int cnt = int.Parse(tokens[1]);
                    recvDt = text;
                    this.Invoke(new MethodInvoker(delegate ()
                    {
                        foreach (Form OpenForm in Application.OpenForms)
                        {
                            if (OpenForm.Text == "Group Talk ( " + cnt + " 명 )")
                            {
                                OpenForm.Activate();
                                return;
                            }
                        }
                        Group_Talk gt = new Group_Talk(this, mainSock.LocalEndPoint.ToString());
                        gt.Show();
                    }));
                }
            }
            else if (text.Contains("\x02"))
            {
                string[] tokens = text.Split('\x02');
                this.Invoke(new MethodInvoker(delegate () { ClientList.Items.Clear(); }));
                for (int i = tokens.Length - 2; i >= 0; i--)
                    this.Invoke(new MethodInvoker(delegate () { ClientList.Items.Add(tokens[i]); }));
            }
            else if (text.Contains("서버 종료"))
            {
                mainSock.Disconnect(true);
                this.Invoke(new MethodInvoker(delegate () { ClientList.Items.Clear(); }));
                AppendText(txtHistory, string.Format("서버와의 연결이 종료되었습니다."));
                ServerConnected = false;
                obj.ClearBuffer();
                mainSock.Close();
                mainSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
                return;
            }
            obj.ClearBuffer();
            obj.WorkingSocket.BeginReceive(obj.Buffer, 0, 50000, 0, DataReceived, obj);
        }
    }
}