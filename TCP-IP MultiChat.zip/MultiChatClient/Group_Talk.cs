﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MultiChatClient
{
    public partial class Group_Talk : Form
    {
        Client cliForm;
        string connectUser;

        public Group_Talk(Client clF, string recvip)
        {
            InitializeComponent();
            this.cliForm = clF;
            connectUser = recvip; 
        }
        // 실행
        private void Group_Talk_Load(object sender, EventArgs e)
        {
            if (cliForm.recvDt == "")
            {
                int cnt = cliForm.ClientList.CheckedItems.Count;
                ClientBox.Items.Add(connectUser);
                this.Text = "Group Talk ( " + (cnt + 1) + " 명 )";
                for (int i = cnt - 1; i >= 0; i--)
                    ClientBox.Items.Add(cliForm.ClientList.CheckedItems[i].ToString());
                for (int i = cliForm.ClientList.Items.Count - 1; i >= 0; i--)
                    cliForm.ClientList.SetItemCheckState(i, CheckState.Unchecked);
            }
            else
            {
                string[] tokens = cliForm.recvDt.Split('\x01');
                int cnt = int.Parse(tokens[1]);
                this.Text = "Group Talk ( " + cnt + " 명 )";
                for (int i = cnt + 2; i >= 3; i--)
                    ClientBox.Items.Add(tokens[i]);
                AppendText(txtHistory, string.Format("[받음]{0} > {1}", tokens[0], tokens[2]));
                cliForm.recvDt = "";
            }
        }
        // 창 활성화 시 실행
        public void Group_Talk_Activated(object sender, EventArgs e)
        {
            if (cliForm.recvDt != "")
            {
                string[] tokens = cliForm.recvDt.Split('\x01');
                AppendText(txtHistory, string.Format("[받음]{0} > {1}", tokens[0], tokens[2]));
                cliForm.recvDt = "";
            }
        }
        // 보내기 버튼
        private void Send_Data(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTTS.Text.Trim()))
            {
                txtTTS.Focus();
                return;
            }
            string sendDt = ClientBox.Items.Count.ToString() + '\x01' + txtTTS.Text + '\x01';
            foreach (string cliList in ClientBox.Items)
                sendDt += cliList + '\x01';
            cliForm.recvDt = sendDt;
            AppendText(txtHistory, string.Format("[보냄]{0} < {1}", connectUser, txtTTS.Text));
            txtTTS.Clear();
            txtTTS.Focus();
            cliForm.TalkSend();
        }
        // 보내기 버튼 실행
        private void QuickSend(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnSend.PerformClick();
        }
        // 텍스트 붙이는 함수
        void AppendText(Control ctrl, string s)
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                ctrl.Text += Environment.NewLine + s;
                txtHistory.SelectionStart = txtHistory.Text.Length;
                txtHistory.ScrollToCaret();
            }));
        }
    }
}
