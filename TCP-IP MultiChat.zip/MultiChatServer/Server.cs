﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Drawing;
using System.ComponentModel;

namespace MultiChatServer {
    public partial class Server : Form
    {
        delegate void AppendTextDelegate(Control ctrl, string s);
        Socket mainSock;
        IPAddress thisAddress;
        List<Socket> connectedClients = new List<Socket>();

        public Server()
        {
            InitializeComponent();
            mainSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
            AppendTextDelegate Appender = new AppendTextDelegate(AppendText);
        }
        // 실행
        private void OnFormLoaded(object sender, EventArgs e)
        {
            IPHostEntry he = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress addr in he.AddressList)
            {
                if (addr.AddressFamily == AddressFamily.InterNetwork) {
                    thisAddress = addr;
                    break;
                }    
            }
            if (thisAddress == null) thisAddress = IPAddress.Loopback;
            txtAddress.Text = thisAddress.ToString();
        }
        // 시작 버튼
        private void BeginStartServer(object sender, EventArgs e)
        {
            int port;
            if (!int.TryParse(txtPort.Text, out port))
            {
                MsgBoxHelper.Error("포트 번호가 잘못 입력되었거나 입력되지 않았습니다.");
                txtPort.Focus();
                txtPort.SelectAll();
                return;
            }
            if (mainSock.IsBound)
            {
                MsgBoxHelper.Warn("서버가 실행중입니다.");
                return;
            }
            IPEndPoint serverEP = new IPEndPoint(thisAddress, port);
            mainSock.Bind(serverEP);
            mainSock.Listen(10);
            mainSock.BeginAccept(AcceptCallback, null);
            AppendText(txtHistory, string.Format("서버가 실행되었습니다."));
        }
        // 보내기 버튼
        private void OnSendData(object sender, EventArgs e)
        {
            if (!mainSock.IsBound)
            {
                MsgBoxHelper.Warn("서버가 실행되고 있지 않습니다!");
                return;
            }
            string tts = txtTTS.Text.Trim();
            if (string.IsNullOrEmpty(tts))
            {
                txtTTS.Focus();
                return;
            }
            byte[] bDts = Encoding.UTF8.GetBytes("[서버]" + '\x01' + tts);
            for (int i = connectedClients.Count - 1; i >= 0; i--)
            {
                Socket socket = connectedClients[i];
                try { socket.Send(bDts); } catch
                {
                    try { socket.Dispose(); } catch { }
                    connectedClients.RemoveAt(i);
                }
            }
            AppendText(txtHistory, string.Format("[보냄][서버]: {0}", tts));
            txtTTS.Clear();
        }
        // 보내기 버튼 실행키
        private void QuickSend(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnSend.PerformClick();
        }
        // 서버 종료시 클라와 연결 끊기
        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (mainSock.IsBound)
            {
                byte[] bDts = Encoding.UTF8.GetBytes("서버 종료");
                for (int i = connectedClients.Count - 1; i >= 0; i--)
                {
                    Socket socket = connectedClients[i];
                    try { socket.Send(bDts); }
                    catch
                    {
                        try { socket.Dispose(); } catch { }
                        connectedClients.RemoveAt(i);
                    }
                }
            }
        }
        // 텍스트 붙이는 함수
        void AppendText(Control ctrl, string s)
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                ctrl.Text += Environment.NewLine + s;
                txtHistory.SelectionStart = txtHistory.Text.Length;
                txtHistory.ScrollToCaret();
            }));
        }
        // 클라 연결 함수
        void AcceptCallback(IAsyncResult ar)
        {
            Socket client = mainSock.EndAccept(ar);
            mainSock.BeginAccept(AcceptCallback, null);
            AsyncObject obj = new AsyncObject(81920);
            obj.WorkingSocket = client;
            connectedClients.Add(client);
            this.Invoke(new MethodInvoker(delegate () { ClientList.Items.Add(client.RemoteEndPoint); }));
            string iptext = "";
            for (int i = connectedClients.Count - 1; i >= 0; i--)
                iptext += connectedClients[i].RemoteEndPoint.ToString() + '\x02';
            byte[] lbip = Encoding.UTF8.GetBytes(iptext);
            for (int i = connectedClients.Count - 1; i >= 0; i--)
            {
                Socket socket = connectedClients[i];
                try { socket.Send(lbip); }
                catch
                {
                    try { socket.Dispose(); } catch { }
                    connectedClients.RemoveAt(i);
                }
            }
            AppendText(txtHistory, string.Format("클라이언트 (@ {0})가 연결되었습니다.", client.RemoteEndPoint));
            client.BeginReceive(obj.Buffer, 0, 50000, 0, DataReceived, obj);
        }
        // 데이터 수신 함수
        void DataReceived(IAsyncResult ar)
        {
            AsyncObject obj = (AsyncObject)ar.AsyncState;
            string text = Encoding.UTF8.GetString(obj.Buffer);
            if (text.Contains("\x04"))
            {
                string[] InfoDt = text.Split('\x04');
                string[] tokens = InfoDt[1].Split('\x01');
                int cnt = int.Parse(tokens[0]);
                for (int j = cnt; j >= 1; j--)
                {
                    for (int i = connectedClients.Count - 1; i >= 0; i--)
                    {
                        if (tokens[j].Equals(connectedClients[i].RemoteEndPoint.ToString()))
                        {
                            Socket socket = connectedClients[i];
                            if (socket != obj.WorkingSocket)
                            {
                                try { socket.Send(obj.Buffer); }
                                catch
                                {
                                    try { socket.Dispose(); } catch { }
                                    connectedClients.RemoveAt(i);
                                }
                            }
                            break;
                        }
                    }
                }
            }
            else if (text.Contains("\x01"))
            {
                string[] tokens = text.Split('\x01');
                if (tokens[1].Contains("\x02")) // 게임톡
                {
                    string[] Infom = tokens[1].Split('\x02');
                    int cnt = int.Parse(Infom[0]);
                    for (int j = cnt + 1; j >= 2; j--)
                    {
                        for (int i = connectedClients.Count - 1; i >= 0; i--)
                        {
                            if (tokens[j].Equals(connectedClients[i].RemoteEndPoint.ToString()))
                            {
                                Socket socket = connectedClients[i];
                                if (socket != obj.WorkingSocket)
                                {
                                    try { socket.Send(obj.Buffer); }
                                    catch
                                    {
                                        try { socket.Dispose(); } catch { }
                                        connectedClients.RemoveAt(i);
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
                else if (tokens.Length == 2) // 전체톡
                {
                    AppendText(txtHistory, string.Format("[받음]{0}: {1}", tokens[0], tokens[1]));
                    for (int i = connectedClients.Count - 1; i >= 0; i--)
                    {
                        Socket socket = connectedClients[i];
                        if (socket != obj.WorkingSocket)
                        {
                            try { socket.Send(obj.Buffer); }
                            catch
                            {
                                try { socket.Dispose(); } catch { }
                                connectedClients.RemoveAt(i);
                            }
                        }
                    }
                }
                else if (tokens.Length == 3) // 갠톡
                {
                    for (int i = connectedClients.Count - 1; i >= 0; i--)
                    {
                        if (tokens[1].Equals(connectedClients[i].RemoteEndPoint.ToString()))
                        {
                            Socket socket = connectedClients[i];
                            if (socket != obj.WorkingSocket)
                            {
                                try { socket.Send(obj.Buffer); }
                                catch
                                {
                                    try { socket.Dispose(); } catch { }
                                    connectedClients.RemoveAt(i);
                                }
                            }
                            break;
                        }
                    }
                }
                else if (tokens.Length >= 4) // 그룹톡 / 배열 위치 : 0 = 본인 ip, 1 = 인원수, 2 = 내용, 3~ = 그룹방 인원 ip
                {
                    int cnt = int.Parse(tokens[1]);
                    for (int j = cnt + 2; j >= 3; j--)
                    {
                        for (int i = connectedClients.Count - 1; i >= 0; i--)
                        {
                            if (tokens[j].Equals(connectedClients[i].RemoteEndPoint.ToString()))
                            {
                                Socket socket = connectedClients[i];
                                if (socket != obj.WorkingSocket)
                                {
                                    try { socket.Send(obj.Buffer); }
                                    catch
                                    {
                                        try { socket.Dispose(); } catch { }
                                        connectedClients.RemoveAt(i);
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
            }
            else if (text.Contains("\x02")) // 클라 접속종료
            {
                string[] tokens = text.Split('\x02');
                this.Invoke(new MethodInvoker(delegate ()
                {
                    for (int i = connectedClients.Count - 1; i >= 0; i--)
                    {
                        if (tokens[0] == connectedClients[i].RemoteEndPoint.ToString())
                        {
                            ClientList.Items.Remove(connectedClients[i].RemoteEndPoint);
                            connectedClients.Remove(connectedClients[i]);
                            break;
                        }
                    }
                    string iptext = "";
                    for (int i = connectedClients.Count - 1; i >= 0; i--)
                        iptext += connectedClients[i].RemoteEndPoint.ToString() + '\x02';
                    byte[] lbip = Encoding.UTF8.GetBytes(iptext);
                    for (int i = connectedClients.Count - 1; i >= 0; i--)
                    {
                        Socket socket = connectedClients[i];
                        try { socket.Send(lbip); }
                        catch
                        {
                            try { socket.Dispose(); } catch { }
                            connectedClients.RemoveAt(i);
                        }
                    }
                }));
                obj.WorkingSocket.Close();
                return;
            }
            obj.ClearBuffer();
            obj.WorkingSocket.BeginReceive(obj.Buffer, 0, 50000, 0, DataReceived, obj);
        }
    }
}