package Client;

public class ClientLoginMain {

	public static void main(String[] args) {
		ClientLogin login = new ClientLogin();
	}

}


