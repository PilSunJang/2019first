package Server;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class ManegerMainSeat extends JPanel {
	JPanel contentPane;


	public ManegerMainSeat() {
		setVisible(true);
		contentPane = new JPanel();
		setBackground(Color.pink);
		add(contentPane);
	}

}