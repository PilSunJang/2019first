package ButtonArray;

import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public abstract class ButtonToArray extends JPanel{
	public ButtonClass ClassArray[] = new ButtonClass[50];
	
}
